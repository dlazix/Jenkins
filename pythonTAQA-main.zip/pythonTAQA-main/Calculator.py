class Calculator:
    def sumFromNumbers(self,firstNumber,secondNumber):
        result = firstNumber + secondNumber
        return result


