# pythonTAQA
Public repo Test Automation and Quality Assurance Python course
